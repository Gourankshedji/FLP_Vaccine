package com.cg.flp.exception;

public class AvailabilityNotFoundException extends RuntimeException {
	public AvailabilityNotFoundException(String message) {
		super(message);
	}
}
