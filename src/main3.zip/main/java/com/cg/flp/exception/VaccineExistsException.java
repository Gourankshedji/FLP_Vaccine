package com.cg.flp.exception;

public class VaccineExistsException extends RuntimeException  {
public VaccineExistsException (String msg) {
	super(msg);

}
}
