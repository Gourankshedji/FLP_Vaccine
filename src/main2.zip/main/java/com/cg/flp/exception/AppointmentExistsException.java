package com.cg.flp.exception;

public class AppointmentExistsException extends RuntimeException {
	public AppointmentExistsException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}
}
