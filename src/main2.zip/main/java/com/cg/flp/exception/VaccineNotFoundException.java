package com.cg.flp.exception;

public class VaccineNotFoundException extends RuntimeException {
public VaccineNotFoundException(String msg) {
	super(msg);
}
}
