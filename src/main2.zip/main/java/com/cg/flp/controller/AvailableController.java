package com.cg.flp.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.flp.entities.Appointment;
import com.cg.flp.entities.Available;
import com.cg.flp.service.IAvailableService;

@RestController
@RequestMapping("Vaccine/available")
public class AvailableController {
	
	@Autowired
	IAvailableService service;
	@PostMapping("/bookAppointment")
	public ResponseEntity<Object> addAvailibility(@Valid @RequestBody Available available ) {

		Available availabletData;
		
			availabletData = service.addAvailability(available);
			return new ResponseEntity<Object>(availabletData, HttpStatus.OK);
		
	}
}
