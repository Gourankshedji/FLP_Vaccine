package com.cg.flp.service;

import com.cg.flp.entities.Available;

public interface IAvailableService {

	public Available addAvailability(Available add);
}
