package com.cg.flp.entities;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.FutureOrPresent;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;

import org.hibernate.validator.constraints.Length;

@Entity
@Table(name = "appointment_master")

public class Appointment {
@Id
@GeneratedValue
	private int appointmentId;
//@OneToOne(cascade=CascadeType.PERSIST)
//@JoinColumn(name="userId")
//User userId;
@NotEmpty(message="Enter your 12 digit Adhar Number")
@Length(min = 12,max = 12)
	private String adharNo;
	@OneToOne(cascade = CascadeType.MERGE)
	@JoinColumn(name="hospitalId" )
	private Hospital hospitalId;
	private String gender;
	@NotNull(message="Enter Date of Birth")
	@Past(message="Enter Past date")
	private LocalDate dob;
//	@NotNull(message="Enter Date To book Appointment For get vaccinated")
//	@FutureOrPresent(message="Enter date of Today's or future date)")
//	private LocalDate appointmentDate;
//	private String time;
	@OneToOne(cascade = CascadeType.MERGE)
	@JoinColumn(name="availabledateandtime")
	private Available available;
	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="vaccine_Id")
	private Vaccine vaccineId;
	
	
	public Appointment() {
		super();
	}

	
	public Appointment( String adharNo, Hospital hospitalId, String gender, LocalDate dob, Available available,
			 Vaccine vaccineId) {
		super();
		this.adharNo = adharNo;
		this.hospitalId = hospitalId;
		this.gender = gender;
		this.dob = dob;
//		this.appointmentDate = appointmentDate;
//		this.time = time;
		this.available=available;
		this.vaccineId = vaccineId;
	}

	
public Appointment(int appointmentId, String adharNo, Hospital hospitalId, String gender, LocalDate dob,Available available,
			 Vaccine vaccineId) {
		super();
		this.appointmentId = appointmentId;
		this.adharNo = adharNo;
		this.hospitalId = hospitalId;
		this.gender = gender;
		this.dob = dob;
//		this.appointmentDate = appointmentDate;
//		this.time = time;
		this.available=available;

		this.vaccineId = vaccineId;
	}

	
	public Available getAvailable() {
	return available;
}


public void setAvailable(Available available) {
	this.available = available;
}


	public int getAppointmentId() {
		return appointmentId;
	}

	public void setAppointmentId(int appointmentId) {
		this.appointmentId = appointmentId;
	}

	public String getAdharNo() {
		return adharNo;
	}

	public void setAdharNo(String adharNo) {
		this.adharNo = adharNo;
	}

	public Hospital getHospitalId() {
		return hospitalId;
	}

	public void setHospitalId(Hospital hospitalId) {
		this.hospitalId = hospitalId;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

//	public LocalDate getAppointmentDate() {
//		return appointmentDate;
//	}
//
//	public void setAppointmentDate(LocalDate appointmentDate) {
//		this.appointmentDate = appointmentDate;
//	}
//
//	public String getTime() {
//		return time;
//	}
//
//	public void setTime(String time) {
//		this.time = time;
//	}

	
	  public Vaccine getVaccineId() { 
		  return vaccineId; 
		  }
	 
	public void setVaccineId(Vaccine vaccineId) {
		this.vaccineId = vaccineId;
	}


	@Override
	public String toString() {
		return "Appointment [appointmentId=" + appointmentId + ", adharNo=" + adharNo + ", hospitalId=" + hospitalId
				+ ", gender=" + gender + ", dob=" + dob + ", available=" + available + ", vaccineId=" + vaccineId + "]";
	}

	
	
	
	
	
}
