package com.cg.flp.serviceImpl;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.flp.entities.Appointment;
import com.cg.flp.entities.Available;
import com.cg.flp.exception.AppointmentExistsException;
import com.cg.flp.repository.IAppointmentRepository;
import com.cg.flp.repository.IAvailableRepository;
import com.cg.flp.service.IAvailableService;


@Service
@Transactional
public class AvailableService implements IAvailableService {
	@Autowired
	IAvailableRepository repository;
	@Override
	public Available addAvailability(Available available) {
	
		
		Available availableData =repository.save(available);


			return availableData;
	}	


}
