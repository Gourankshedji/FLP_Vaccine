package com.cg.flp.exception;

public class BookingNotDoneException extends Exception {
public BookingNotDoneException (String message) {
	super(message);
}
}




